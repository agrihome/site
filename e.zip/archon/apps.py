from django.apps import AppConfig


class ArchonConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "archon"
